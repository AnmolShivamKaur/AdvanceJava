package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String phoneNo=request.getParameter("phoneNo");
		String email=request.getParameter("email");
		String date1=request.getParameter("date1");
	
		String hobbies[]=request.getParameterValues("hobbies");
		String setPassword=request.getParameter("setPassword");
		String confirmPassword=request.getParameter("confirmPassword");
		PrintWriter out=response.getWriter();
		out.println("<html><body><div align='center'>");
		out.print("<table><tr><td>Full Name:</td><td>"+firstName+" "+lastName+"</td></tr>");
		out.print("<tr><td>EmailId:</td><td>"+email+"</td></tr>");
		out.print("<tr><td>PhoneNo:</td><td>"+phoneNo+"</td></tr>");
		out.print("<tr><td>Date of Birth:</td><td>"+date1+"</td></tr>");
		out.print("<tr><td>Hobbies:</td>");
		for(String values:hobbies)
			out.print("<td>"+values+"</td>");
		out.print("</tr></div></body></html>");
		
	}

  
}
