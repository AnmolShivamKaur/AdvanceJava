package com.cg.payroll.exceptions;

public class AssociateDetailNotFoundException extends Exception{

	public AssociateDetailNotFoundException() {
		super();
		
	}

	public AssociateDetailNotFoundException(String arg0, Throwable arg1,
			boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		
	}

	public AssociateDetailNotFoundException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}

	public AssociateDetailNotFoundException(String arg0) {
		super(arg0);
		
	}

	public AssociateDetailNotFoundException(Throwable arg0) {
		super(arg0);
		
	}

}
